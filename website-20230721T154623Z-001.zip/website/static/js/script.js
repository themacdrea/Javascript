function toggleTheme() {
    var body = document.body;
    body.classList.toggle("dark-mode");
  }