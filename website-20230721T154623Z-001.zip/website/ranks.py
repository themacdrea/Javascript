from flask import Blueprint, render_template, jsonify
from pathlib import Path
from sqlalchemy.orm import Session
from sqlalchemy import create_engine, func, inspect
from website.config import username, password, host, port, database_name

engine = create_engine(f"postgresql://{username}:{password}@{host}:{port}/{database_name}")

ranks = Blueprint('ranks', __name__)

@ranks.route('/')
def graph_1():
    session = Session(engine)

    # result1 = session.execute('SELECT "Zodiac_Sign" FROM Male')
    
    # print(result1)

    # Query the data from the "Male" table
    result = session.query(func.count(), "Zodiac_Sign").group_by("Zodiac_Sign").all()

     # Sort the results by count in descending order
    sorted_results = sorted(result, key=lambda x: x[0], reverse=True)

    # Rank the zodiac signs based on the count
    ranked_zodiacs = [zodiac for count, zodiac in sorted_results]

    return render_template("ranks.html", ranked_zodiacs=ranked_zodiacs)
    # return render_template("ranks.html", text=result1)

