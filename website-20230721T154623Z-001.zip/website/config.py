# Credentials

username = 'postgres'
password = 'XVwuUz&5Tndw*Jn'
host = 'localhost'
port = '5432'
database_name = 'Divorce_db'
key = 'randomgjdkrfsgr'
